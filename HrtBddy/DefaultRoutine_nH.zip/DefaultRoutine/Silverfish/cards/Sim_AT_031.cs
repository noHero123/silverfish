using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_AT_031 : SimTemplate //Cutpurse
    {

        //Whenever this minion attacks a hero, add the Coin to your hand.
        // done in triggerAMinionIsGoingToAttack(...)


    }

}