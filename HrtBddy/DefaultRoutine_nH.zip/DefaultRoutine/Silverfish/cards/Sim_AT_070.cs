﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_AT_070 : SimTemplate //Skycap'n Kragg
    {

        //Charrrrrge Costs (1) less for each friendly Pirate

        
       

    }
}