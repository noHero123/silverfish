﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{

    class Sim_AT_037t : SimTemplate // 1/1 sappling
    {
        //a 1/1 sappling


    }

    
}
