﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_AT_088 : SimTemplate //Mogor's Champion
    {

        //50% chance to attack the wrong enemy.

        //TODO

       
    }
}