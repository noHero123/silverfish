﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_AT_092 : SimTemplate //Ice Rager
    {

        //nothing

       
    }
}