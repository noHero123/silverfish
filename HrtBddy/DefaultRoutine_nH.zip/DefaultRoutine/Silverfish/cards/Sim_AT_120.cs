using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_AT_120 : SimTemplate //Frost Giant
    {

        //Costs (1) less for each time you used your Hero Power this game
    

       


    }

}