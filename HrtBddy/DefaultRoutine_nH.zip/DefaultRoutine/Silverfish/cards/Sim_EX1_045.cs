using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_045 : SimTemplate //ancientwatcher
	{

//    kann nicht angreifen.
		

	}
}