using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_170 : SimTemplate //emperorcobra
	{

//    vernichtet jeden diener, der von diesem diener verletzt wurde.

	}
}