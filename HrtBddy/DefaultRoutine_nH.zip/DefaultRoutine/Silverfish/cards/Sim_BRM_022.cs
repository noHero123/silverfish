﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_BRM_022 : SimTemplate //Dragon Egg
    {

        //   Whenever this minion takes damage, summon a 2/1 Whelp.

        //done in playfield triggerAMinionGotDmg()

    }
}