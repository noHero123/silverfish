using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_050 : SimTemplate //searingtotem
	{

// fire totem of shaman ability
		

	}
}