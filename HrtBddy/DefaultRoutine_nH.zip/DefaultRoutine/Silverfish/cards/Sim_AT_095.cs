﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_AT_095 : SimTemplate //Silent Knight
    {

        //stealth + div shield

       
    }
}