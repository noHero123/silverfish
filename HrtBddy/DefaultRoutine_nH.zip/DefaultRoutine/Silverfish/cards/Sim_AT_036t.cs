﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{

    class Sim_AT_036t : SimTemplate // 4/4 nerub
    {
        //a 4/4 Nerubian.


    }

    
}
