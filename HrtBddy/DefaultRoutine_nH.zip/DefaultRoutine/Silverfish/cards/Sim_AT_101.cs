using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_AT_101 : SimTemplate //Pit Fighter
    {

       


    }


}