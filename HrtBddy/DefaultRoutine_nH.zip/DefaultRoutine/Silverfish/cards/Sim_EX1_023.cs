﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_EX1_023 : SimTemplate//Silvermoon Guardian
    {


    }
}
