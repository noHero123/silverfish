using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS1_042 : SimTemplate //goldshirefootman
	{

//    spott/


	}
}