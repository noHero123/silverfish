﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{

    class Sim_AT_041 : SimTemplate // Knight of the Wild
    {
        //Whenever you summon a Beast, reduce the Cost of this card by (1).
        //done in triggerAMinionIsSummoned

    }

    
}
