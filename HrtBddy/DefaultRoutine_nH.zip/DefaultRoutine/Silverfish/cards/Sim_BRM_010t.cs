using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_BRM_010t : SimTemplate //druidoftheclaw
	{


	}
}