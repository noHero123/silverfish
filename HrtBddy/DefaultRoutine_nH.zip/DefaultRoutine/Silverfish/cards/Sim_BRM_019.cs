﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_BRM_019 : SimTemplate //Grim Patron
    {

        //    Whenever this minion survives damage, summon another Grim Patron.

        //done in playfield triggerAMinionGotDmg()

    }
}