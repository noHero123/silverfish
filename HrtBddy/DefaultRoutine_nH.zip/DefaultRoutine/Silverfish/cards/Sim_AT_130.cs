﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_AT_130 : SimTemplate //Sea Reaver
    {

        //When you draw this, deal 1 damage to your minions.

        //not simulated!
        //TODO simulate this with  p.isServer!

       

    }
}